import Foundation

func sum(numbers: [Int]) -> Int {
    var total = 0
    for number in numbers {
        total += number
    }
    return total
}

let sumClosure = { (numbers: [Int]) -> Int in
    var total = 0
    for number in numbers {
        total += number
    }
    return total
}

let sum = sumClosure([1, 2, 3, 4])

let printClosure = { () -> Void in
    print("Замыкание без параметров и без возвращаемого значения")
}

let printClosure2 = { (string: String) -> Void in
    print("Замыкание с параметром, но без возвращаемого значения")
}

let randomNumberClosure = { () -> Int in
    print("Замыкание без параметра, но с возвращаемым значением")
    return Int.random(in: 0..<10)
}

let randimNumberClosure2 = { (minValue: Int, maxValue: Int) -> Int in
    print("Замыкание с параметрами и возвращаемым значением")
    return Int.random(in: minValue...maxValue)
}

struct Track {
    var starRating: Int
    var trackNumber: Int
}

let tracks = [
    Track(starRating: 3, trackNumber: 4),
    Track(starRating: 5, trackNumber: 3),
    Track(starRating: 5, trackNumber: 2),
    Track(starRating: 4, trackNumber: 1),
]

let sortedTracks = tracks.sorted { (firstTrack, secondTrack) -> Bool in
    return firstTrack.trackNumber < secondTrack.trackNumber
}

let sortedByRating = tracks.sorted { (firstTrack, secondTrack) -> Bool in
    return firstTrack.starRating < secondTrack.starRating
}

let sortedByRating2 = tracks.sorted { (firstTrack, secondTrack) in
    return firstTrack.starRating < secondTrack.starRating
}

let sortedByRating3 = tracks.sorted { firstTrack, secondTrack in
    return firstTrack.starRating < secondTrack.starRating
}

let sortedByRating4 = tracks.sorted { return $0.starRating < $1.starRating }

let sortedByRating5 = tracks.sorted { $0.starRating < $1.starRating }

extension Track: Comparable {
    static func < (lhs: Track, rhs: Track) -> Bool {
        return lhs.starRating < rhs.starRating
    }
}

let sortedByRating6 = tracks.sorted { $0 < $1 }

let sortedByRating7 = tracks.sorted(by: <)

let names = ["Николай", "Владимир", "Иосиф", "Никита", "Леонид", "Юрий", "Константин", "Михаил", "Борис", "Владимир"]

var fullNames = [String]()

for name in names {
    let fullName = name + " X"
    fullNames.append(fullName)
}

print(fullNames)

fullNames = names.map { $0 + " X" }

print(fullNames)

let tuples = names.map { ($0, "X") }

print(tuples)

let numbers = [4, 8, 15, 16, 23, 42]
var numbersLessThan20 = [Int]()

for number in numbers {
    if number < 20 {
        numbersLessThan20 += [number]
    }
}

print(numbersLessThan20)

numbersLessThan20 = numbers.filter { $0 < 20 }

print(numbersLessThan20)

var total = 0

total = sum(numbers: numbers)

total = numbers.reduce(0, { $0 + $1 })
print(total)

var dict = [1: "Иван", 2: "Пётр", 10: "Фёдор"]

var array = dict.reduce([]) { $0 + ["\($1.key)", $1.value] }

print(array)
